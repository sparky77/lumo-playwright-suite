if (typeof console === "undefined" || typeof console.log === "undefined") {  
                                console = { };
                                console.log = function(msg) {};
                                }
                                console.log("The script has been deactivated because the client is inactive.");